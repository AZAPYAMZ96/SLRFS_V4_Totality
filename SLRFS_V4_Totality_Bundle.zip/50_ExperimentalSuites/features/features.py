import numpy as np
def extract_features(frames, audio_block, imu_block, hrv=None):
    return {"phases": np.array([0.0]), "conflict_features": {"overlap_rate": 0.0, "motion_clash": 0.0}}
if __name__ == "__main__":
    print("[features] placeholder up")
