# Seel Lens iQ — Index Core (Starter Repo)

This starter repo scaffolds an MVP/alpha device that measures group/system coherence vs. tension in real time and emits feedback to increase coherence. It logs all metrics into the Seel Index.

See `/safety/safety_checklist.md`, `/hardware/bom.csv`, and `/manufacturing_pack` for build details.
