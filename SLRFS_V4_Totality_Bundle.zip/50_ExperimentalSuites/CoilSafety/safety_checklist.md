# Safety Checklist (Alpha)

- EMF caps, thermal caps, privacy defaults.
