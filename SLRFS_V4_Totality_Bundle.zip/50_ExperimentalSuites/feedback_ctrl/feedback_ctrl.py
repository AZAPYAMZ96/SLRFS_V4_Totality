import numpy as np
class FeedbackController:
    def __init__(self, caps=None):
        self.caps = caps or {"max_led_pwm":0.6,"max_haptic":0.5,"max_coil_b_mT":2.0,"max_coil_duty":0.25}
    def policy(self, metrics):
        V = metrics.get("V",50)
        pattern = {"led_pwm": min(self.caps["max_led_pwm"], 0.05 + 0.009*V), "haptic": 0.0, "coil": {"freq_khz": 12, "duty": 0.0}}
        return pattern
if __name__=="__main__":
    print("[feedback-ctrl] demo:", FeedbackController().policy({"V":70}))


# --- coilsafe integration ---
try:
    from services.coilsafe.coilsafe import safe_command
except Exception:
    import sys, os
    sys.path.append(os.path.join(os.path.dirname(__file__), "..", "coilsafe"))
    from coilsafe import safe_command

class CoilLimiter:
    def __init__(self, turns=30, radius_m=0.02):
        self.turns = turns; self.radius_m = radius_m
    def clamp(self, cmd):
        ok, reason = safe_command(cmd.get('freq_khz',12), cmd.get('duty',0.0), cmd.get('current_a',0.0),
                                  self.turns, self.radius_m)
        if not ok:
            return {'freq_khz': cmd.get('freq_khz',12), 'duty': 0.0, 'current_a': 0.0, 'reason': reason}
        return cmd

_limiter = CoilLimiter()

def apply_policy_to_actuators(metrics):
    coil_cmd = {'freq_khz': 12, 'duty': 0.15, 'current_a': 0.4}
    coil_cmd = _limiter.clamp(coil_cmd)
    return {'coil_cmd': coil_cmd}
