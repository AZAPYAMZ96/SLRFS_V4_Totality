# Wiring notes

- Camera→CSI, Mics→I2S, IMU→I2C, LED→SPI, Haptic→I2C, Coil→PWM driver
