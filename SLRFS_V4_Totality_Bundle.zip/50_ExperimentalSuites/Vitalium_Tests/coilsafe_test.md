# CoilSafe Test
- Geometry: N=30 turns, radius=20 mm
- Command: 12 kHz, duty 0.2, current 0.5 A
- Expect clamp if B_rms > 2 mT; see reason string.
