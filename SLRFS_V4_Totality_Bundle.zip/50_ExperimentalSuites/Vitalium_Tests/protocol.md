# Field Test Protocol

Scenes: quiet focus, discussion, movement with music.
