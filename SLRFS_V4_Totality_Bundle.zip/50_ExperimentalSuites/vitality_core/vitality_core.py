import numpy as np, networkx as nx
class VitalityCore:
    def __init__(self, window_sec=8.0, ema_tau=3.0):
        self.window_sec = window_sec; self.ema_tau = ema_tau
        self.beta1 = 1.0; self.beta2 = 1.0; self.v_ema=None
    @staticmethod
    def order_parameter(phases):
        z = np.exp(1j*phases); return np.abs(np.mean(z))
    @staticmethod
    def wrapped_sq_diff(a,b):
        import numpy as np
        d = np.angle(np.exp(1j*(a-b))); return d*d
    def tension(self, G, phases, conflict_features, lam=0.3):
        if len(phases)==0 or G.number_of_edges()==0: disp=0.0
        else:
            disp=0.0
            for u,v,w in G.edges(data=True):
                wij=w.get("w",1.0); disp += wij*self.wrapped_sq_diff(phases[u], phases[v])
            disp /= max(G.number_of_edges(),1)
        cf = 0.0
        if conflict_features:
            cf = 0.5*conflict_features.get("overlap_rate",0.0)+0.5*conflict_features.get("motion_clash",0.0)
        return disp + lam*cf
    def step(self, phases, G, conflict_features):
        R=self.order_parameter(phases); T=self.tension(G, phases, conflict_features); V=1.0*R-1.0*T
        V_scaled = max(0.0, min(100.0, 50.0 + 50.0*V))
        if self.v_ema is None: self.v_ema=V_scaled
        alpha = 1.0 - np.exp(-1.0/max(self.ema_tau,1e-6))
        self.v_ema = (1-alpha)*self.v_ema + alpha*V_scaled
        return {"R":R,"Tension":T,"V":self.v_ema}
if __name__=="__main__":
    G=nx.Graph(); G.add_edge(0,1,w=1.0)
    vc=VitalityCore(); print("[vitality-core] demo:", vc.step(np.array([0.0,0.2]), G, {"overlap_rate":0.1,"motion_clash":0.05}))
