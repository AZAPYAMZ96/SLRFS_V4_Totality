# coilsafe.py — compute B-field and enforce safety
import math
MU0 = 4*math.pi*1e-7  # H/m
def b_on_axis_center(turns, radius_m, current_a):
    return MU0 * turns * current_a / (2*radius_m)
def max_current_for_limit(b_limit_t, turns, radius_m):
    return (2*radius_m * b_limit_t) / (MU0 * turns)
def safe_command(freq_khz, duty, current_a, turns, radius_m, b_limit_t=2e-3, max_duty=0.25, f_min=5e3, f_max=40e3):
    if not (f_min <= freq_khz*1e3 <= f_max):
        return False, f"freq {freq_khz} kHz out of range [{f_min/1e3},{f_max/1e3}] kHz"
    if duty < 0 or duty > max_duty:
        return False, f"duty {duty:.2f} exceeds {max_duty:.2f}"
    b_center = b_on_axis_center(turns, radius_m, current_a) * math.sqrt(max(duty, 1e-9))
    if b_center > b_limit_t:
        i_max = max_current_for_limit(b_limit_t, turns, radius_m)
        return False, f"B_rms {b_center*1e3:.2f} mT exceeds {b_limit_t*1e3:.2f} mT; reduce current ≤ {i_max:.2f} A"
    return True, "ok"
if __name__=='__main__':
    ok, reason = safe_command(12, 0.2, 0.5, 30, 0.02); print('[coilsafe]', ok, reason)
