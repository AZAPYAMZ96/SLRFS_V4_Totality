#include <iostream>
int main() {
  std::cout << "[sensor-hub] starting..." << std::endl;
  return 0;
}
