

## v4 Additions
- Added 50_ExperimentalSuites/ (MFG, CoilSafety, Vitalium_Tests)
- Added 60_ReefOS_Codebase/ (Core_Starter)
- Source: index-core-starter_v2_with_mfg_and_coilsafe.zip
